# Sample Project
Nested folder structure for zip extraction practice.
