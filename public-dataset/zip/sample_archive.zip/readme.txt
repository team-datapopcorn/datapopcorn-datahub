This is a sample flat zip archive for extraction practice.
